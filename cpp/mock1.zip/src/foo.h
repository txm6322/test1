#pragma once

#include <iostream>
#include <string>

int dep1(int k);
bool dep2(int k, int* o);

struct A{
    static int dep1(int k) {return ::dep1(k);}
};
struct B{
    static bool dep2(int k, int *o) { return ::dep2(k, o);} 
};
// default template type works with c++11 and above
template<class T1=A, class T2=B>
int foo1(int a) {
    switch(T1::dep1(a)){
    case 1: return 1;
    case 2: return 2;
    default: ; // continue
    }
    int out=0;
    if(!T2::dep2(a, &out))
        throw std::runtime_error("failed");
    return out;
}