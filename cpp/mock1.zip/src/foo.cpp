#include "foo.h"

int dep1(int k){
    return k+1;
}
bool dep2(int k, int* o){
    if(k == 10) return false;
    *o = k;
    return true;
}
