#include "foo.h"
#include <iostream>

using namespace std;

extern int x(int);
int main(int argc, char** argv){
    cout << "hello 123: " << x(400) << endl;
    cout << "foo1:" << foo1(3) << endl;
}