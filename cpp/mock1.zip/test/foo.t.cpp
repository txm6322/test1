#include <gtest/gtest.h>
#include <gmock/gmock.h>

#include "foo.h"

extern int x(int);

using namespace std;
using ::testing::Eq;
using ::testing::_;
using ::testing::Assign;
using ::testing::ByRef;
using ::testing::Return;
using ::testing::DoAll;
using ::testing::SetArgPointee;
using ::testing::SetArgReferee;
using ::testing::IgnoreResult;
using ::testing::Invoke;
using ::testing::WithArg;

TEST(Suite1, RealCase1){
    EXPECT_EQ(1, foo1(0)) << "existing 1";
    EXPECT_EQ(2, foo1(1)) << "existing 2";
    EXPECT_THROW(foo1(10), std::runtime_error) << "existing 3";
    EXPECT_ANY_THROW(foo1(10)) << "existing 3";
    try{
        foo1(10);
    }catch(const std::runtime_error &e){
        EXPECT_TRUE("failed" == string(e.what()));
    }
    EXPECT_EQ(3, foo1(3)) << "existing 4";
}

struct MockA_ { MOCK_METHOD1(dep1, int(int));};
struct MockA: public A {
    static MockA_ * pUA;
    static int dep1(int k){return pUA->dep1(k);}
};
MockA_ * MockA::pUA = nullptr;

struct MockB_ { MOCK_METHOD2(dep2, bool(int,int*));};
struct MockB: public B {
    static MockB_ * pUB;
    static int dep2(int k, int* o){return pUB->dep2(k, o);}
};
MockB_ * MockB::pUB = nullptr;
int k = 10;
void setV(int v){k=v;cout << "set v=" << k << endl;}
int getV(){
    cout << "before get k=" << k << endl;
    return k;}
void setV1(int v){
    cout << "before k=" << k << endl;
    k=v;cout << "set v=" << k << endl;}

TEST(Suite2, MockCases){
    MockA_ a; MockA::pUA = &a;
    EXPECT_CALL(a, dep1(_)).WillRepeatedly(Return(3));
    MockB_ b; MockB::pUB = &b;
    int y=887;
    EXPECT_CALL(b, dep2(_, _))
       .WillOnce(DoAll(SetArgPointee<1>(999),Return(true)))
       .WillOnce(DoAll(
          //Assign(&y,888),
          //SetArgPointee<1>(ByRef(y)),
          WithArg<0>(setV),
          SetArgPointee<1>(ByRef(k)),
          Return(true)
        ));
    EXPECT_EQ(999, (foo1<MockA, MockB>(999)));
    //EXPECT_EQ(888, (foo1<MockA, MockB>(888)));

}